<template>
    <img
        draggable="false"
        src="/assets/images/logo.png"
        alt="Goodday Schoolicious logo"
    />
</template>
