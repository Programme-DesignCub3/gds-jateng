<script setup lang="ts"></script>
<template>
  <a
    class="fixed bottom-2 right-2 transition-all duration-300 ease-in-out hover:bottom-6 hover:scale-110 md:bottom-4 md:right-4"
    href="http://wa.me/6287766548639"
    target="_blank"
    rel="noopener noreferrer"
  >
    <img
      class="pointer-events-none size-16 md:size-32"
      src="/assets/images/cs.png"
      alt=""
    />
  </a>
</template>

<style scoped></style>
