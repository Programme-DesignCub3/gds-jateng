<script setup lang="ts"></script>
<template>
    <div>
        <div
            class="flex aspect-square items-center justify-center rounded-2xl bg-muted-foreground/50"
        />
        <div class="mt-2 text-xs md:text-base">
            <slot />
        </div>
    </div>
</template>

<style scoped></style>
