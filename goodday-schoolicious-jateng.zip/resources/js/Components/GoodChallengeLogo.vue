<template>
  <img draggable="false" src="/assets/images/GDS.png" alt="Good Challenge logo" />
</template>
