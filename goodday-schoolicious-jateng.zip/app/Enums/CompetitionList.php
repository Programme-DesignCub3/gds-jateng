<?php

namespace App\Enums;

enum CompetitionList: string
{
    case KOLABORASA = 'kolaborasa';
    case CHANTS = 'chants';
    case CHEERLEADING = 'cheerleading';
    case MASCOT = 'mascot-design';
}
